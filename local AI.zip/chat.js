let userName = localStorage.getItem("userName");

// Ask name if not set
window.onload = function () {
  const chatBox = document.getElementById("chatBox");

  if (!userName) {
    const askName = document.createElement("div");
    askName.className = "message bot";
    askName.textContent = " Hello! What should I call you?";
    chatBox.appendChild(askName);
  } else {
    greetUser(userName);
  }
};

function sendMessage() {
  const input = document.getElementById("userInput");
  const chatBox = document.getElementById("chatBox");
  const userMessage = input.value.trim();

  if (userMessage === "") return;


  const userDiv = document.createElement("div");
  userDiv.className = "message user";
  userDiv.textContent = userMessage;
  chatBox.appendChild(userDiv);
  input.value = "";

  if (!userName) {
    userName = userMessage;
    localStorage.setItem("userName", userName);

    const botDiv = document.createElement("div");
    botDiv.className = "message bot";
    botDiv.textContent = `Nice to meet you, ${userName}! `;
    chatBox.appendChild(botDiv);
    return;
  }

  // Show AI reply
  const botDiv = document.createElement("div");
  botDiv.className = "message bot";
  botDiv.textContent = generateReply(userMessage);
  chatBox.appendChild(botDiv);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function generateReply(message) {
  const msg = message.toLowerCase();

  if (msg.includes("hi pet") || msg.includes("hello pet")) {
    return `Hi ${userName}! `;
  }

  if (msg.includes("who am i")) {
    return `You're ${userName}, my awesome creator! `;
  }

  if (msg.includes("what's your name")) {
    return `I'm Your Pet, your assistant and friend! 🐾`;
  }

  if (msg.includes("my name is gyan")) {
    return `Hi Gyan! I think you're one of Shashwat's friends. `;
  }

  if (msg.includes("my name is sdm")) {
    return `Hi Sir SDM (Sanatani Deepak Maurya), also known as the OG Code `;
  }

  if (msg.includes("my name is aditya")) {
    return `Hi Aditya! You're the real Malik, right? `;
  }
    if (msg.includes("what is 2+2")) {
    return `4 `;
  }
if (msg.includes("table of 2")) {
  return `Yes, here it is:<br>
2 × 1 = 2,
2 × 2 = 4,
2 × 3 = 6,
2 × 4 = 8,
2 × 5 = 10,
2 × 6 = 12,
2 × 7 = 14,
2 × 8 = 16,
2 × 9 = 18,
2 × 10 = 20`;
}


  if (msg.includes("yes")) {
    return `Yaa, my owner told me about you! `;
  }

  return `Sorry! I'm still learning, ${userName}. Thank you for talking with me — it helps me grow! 🌱`;
}

function greetUser(name) {
  const chatBox = document.getElementById("chatBox");
  const greeting = document.createElement("div");
  greeting.className = "message bot";
  greeting.textContent = `Welcome back, ${name}! `;
  chatBox.appendChild(greeting);
}
